import requests
from bs4 import BeautifulSoup
import pandas as pd
from io import StringIO

def get_player_game_logs(player_name, season='2023-24'):
    url = f"https://www.statmuse.com/nba/ask/{player_name.replace(' ', '-').lower()}-game-log-{season}"
    headers = {'User-Agent': 'Mozilla/5.0'}

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')

        table = soup.find('table')
        if not table:
            print(f"No game log table found for {player_name} on StatMuse at {url}.")
            return pd.DataFrame()

        try:
            # Wrap the HTML string in StringIO to suppress the FutureWarning
            df = pd.read_html(StringIO(str(table)))[0]
            return df
        except IndexError:
            print(f"Could not parse HTML table for {player_name} on StatMuse. No tables found by pandas.read_html.")
            return pd.DataFrame()

    except requests.exceptions.RequestException as e:
        print(f"Network or HTTP error while scraping StatMuse for {player_name}: {e}")
        return pd.DataFrame()
    except Exception as e:
        print(f"An unexpected error occurred while scraping StatMuse for {player_name}: {e}")
        return pd.DataFrame()

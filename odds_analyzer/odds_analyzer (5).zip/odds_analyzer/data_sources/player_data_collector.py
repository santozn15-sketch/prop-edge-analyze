import pandas as pd
from odds_analyzer.data_sources.manual_input import get_manual_player_data
from odds_analyzer.data_sources.statmuse import get_player_game_logs
from odds_analyzer.data_sources.hofapp import get_hof_data

def get_player_data(player_name, season='2023-24'):
    """
    Unified function to collect player data from various sources with priority.

    Priority Order:
    1. Manual User Input
    2. StatMuse Data (game logs)
    3. HOF Data (e.g., historical stats)

    Args:
        player_name (str): The name of the player.
        season (str): The season to fetch data for (primarily for StatMuse).

    Returns:
        pd.DataFrame: A DataFrame containing combined player data from the highest priority source found.
                      Returns an empty DataFrame if no data can be fetched from any source.
    """
    data = pd.DataFrame()

    # 1. Try Manual Input
    try:
        print(f"Trying manual input for {player_name}...")
        manual_data = get_manual_player_data(player_name)
        if not manual_data.empty:
            print(f"Successfully retrieved manual data for {player_name}.")
            return manual_data
    except Exception as e:
        print(f"Error fetching manual input for {player_name}: {e}")

    # 2. Try StatMuse Data
    try:
        print(f"Trying StatMuse data for {player_name}...")
        statmuse_data = get_player_game_logs(player_name, season=season)
        if not statmuse_data.empty:
            print(f"Successfully retrieved StatMuse data for {player_name}.")
            return statmuse_data
    except Exception as e:
        print(f"Error fetching StatMuse data for {player_name}: {e}")

    # 3. Try HOF Data
    try:
        print(f"Trying HOF app data for {player_name}...")
        hof_data = get_hof_data(player_name)
        if not hof_data.empty:
            print(f"Successfully retrieved HOF data for {player_name}.")
            return hof_data
    except Exception as e:
        print(f"Error fetching HOF data for {player_name}: {e}")

    print(f"Could not retrieve data for {player_name} from any source.")
    return pd.DataFrame()

print("player_data_collector.py module created.")

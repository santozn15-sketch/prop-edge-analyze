# 📈 Odds Analyzer

## Overview

The **Odds Analyzer** is a modular Streamlit application designed for sports betting research. It calculates fair probabilities by removing the 'vig' from sportsbook lines and fetches historical player data to estimate hit rates and true probabilities.

## Features

*   **No-Vig Calculator**: Removes sportsbook juice (vig) to determine true probabilities and fair odds.
*   **Player Research**: Fetches and displays player game logs and historical data from various sources.
*   **True Probability Analyzer**: Compares projected hit rates based on historical data against sportsbook implied probabilities to identify betting edges.

## Project Structure

The project is organized into a modular structure to promote reusability and maintainability:

```
odds_analyzer/
├── app.py                         # Main Streamlit application interface
├── requirements.txt               # Python dependencies
├── README.md                      # Project documentation and setup guide
├── .gitignore                     # Specifies files/folders to ignore in Git
├── __init__.py                    # Makes 'odds_analyzer' a Python package
├── calculations/                  # Contains modules for betting calculations
│   ├── __init__.py
│   ├── novig.py                   # Logic for no-vig calculations
│   └── true_probability.py        # Logic for true probability and hit rate estimation
└── data_sources/                  # Contains modules for data acquisition from various sources
    ├── __init__.py
    ├── player_data_collector.py   # Unified function to fetch player data with priority
    ├── statmuse.py                # Scraper for StatMuse game logs
    ├── hofapp.py                  # Placeholder for HOF app/API data
    ├── manual_input.py            # Placeholder for manual user input data
    └── player_props.py            # Placeholder for scraping player props
```

## Setup and Local Development

Follow these steps to set up and run the Odds Analyzer application on your local machine:

### 1. Clone the Repository

First, clone the project repository from GitHub to your local machine:

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
cd YOUR_REPOSITORY_NAME # or cd odds_analyzer if your repo is named that
```

### 2. Create a Virtual Environment (Recommended)

It's good practice to use a virtual environment to manage project dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows, use `.venv\Scripts\activate`
```

### 3. Install Dependencies

Install all required Python packages listed in `requirements.txt`:

```bash
pip install -r requirements.txt
```

### 4. Run the Streamlit Application

Once dependencies are installed, you can run the Streamlit app:

```bash
streamlit run app.py
```

This will open the application in your web browser. If it doesn't open automatically, look for the local URL in your terminal output (usually `http://localhost:8501`).

## Deployment to Streamlit Cloud

To deploy this application to Streamlit Cloud, you will need to:

1.  **Ensure your project is in a public GitHub repository.**
2.  **Go to [share.streamlit.io](https://share.streamlit.io/) and log in with GitHub.**
3.  **Click "New app" and select your repository, branch, and set the main file path to `app.py`**.
4.  **Configure any necessary advanced settings** (e.g., Python version, secrets for API keys if you add them).
5.  **Click "Deploy!"**

## Contributing

Feel free to contribute to the project by opening issues or submitting pull requests.

import streamlit as st
import pandas as pd
import sys
import os

# Ensure the current directory is in the path for modular imports
sys.path.append(os.path.dirname(__file__))

from calculations.novig import calculate_no_vig
from data_sources.statmuse import get_player_game_logs

st.set_page_config(page_title="Pro Sports Betting Suite", layout="wide")

tabs = st.tabs(["Home", "No Vig Calculator", "Player Research", "True Probability", "Settings"])

with tabs[1]:
    st.header("No-Vig Calculator")
    c1, c2 = st.columns(2)
    over = c1.number_input("Over Odds", value=-110)
    under = c2.number_input("Under Odds", value=-110)
    if st.button("Calculate"):
        res = calculate_no_vig(over, under)
        st.json(res)

with tabs[2]:
    st.header("Player Research")
    name = st.text_input("Player Name", "LeBron James")
    if st.button("Analyze"):
        with st.spinner("Scraping data..."):
            data = get_player_game_logs(name)
            if not data.empty:
                st.dataframe(data)
                st.line_chart(data['PTS'].astype(float))
            else:
                st.error("Could not find data.")

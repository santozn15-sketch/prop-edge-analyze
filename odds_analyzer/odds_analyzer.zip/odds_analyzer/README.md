# 📈 Odds Analyzer

## Overview

The **Odds Analyzer** is a modular Streamlit application designed for sports betting research. It calculates fair probabilities by removing the 'vig' from sportsbook lines and fetches historical player data to estimate hit rates.

## Project Structure

```text
odds_analyzer/
├── app.py                 # Main Streamlit UI
├── requirements.txt        # Python dependencies
├── README.md               # Documentation
├── calculations/          # Logic modules
│   ├── novig.py
│   └── true_probability.py
└── data_sources/           # Scrapers
    ├── statmuse.py
    └── basketball_reference.py
```

## Setup and Local Development

1. **Navigate to the directory**:
   ```bash
   cd odds_analyzer
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the App**:
   ```bash
   streamlit run app.py
   ```

## Features

- **No-Vig Calculator**: Removes sportsbook juice to find fair odds.
- **Player Research**: Scrapes live game logs from StatMuse and visualizes trends.
- **True Probabilities**: Compares historical performance against current betting lines.

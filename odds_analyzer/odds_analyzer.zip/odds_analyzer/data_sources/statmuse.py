import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_player_game_logs(player_name, season='2023-24'):
    url = f"https://www.statmuse.com/nba/ask/{player_name.replace(' ', '-').lower()}-game-log-{season}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table')
        if not table:
            return pd.DataFrame()
            
        df = pd.read_html(str(table))[0]
        return df
    except Exception as e:
        print(f"Error scraping StatMuse: {e}")
        return pd.DataFrame()

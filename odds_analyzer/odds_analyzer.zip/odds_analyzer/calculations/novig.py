def calculate_no_vig(over_odds, under_odds):
    """
    Calculates No-Vig probabilities and fair odds from American odds.
    """
    def to_implied(american_odds):
        if american_odds > 0:
            return 100 / (american_odds + 100)
        return abs(american_odds) / (abs(american_odds) + 100)

    def to_american(prob):
        if prob >= 0.5:
            return int(-100 * prob / (1 - prob))
        return int((1 - prob) / prob * 100)

    p_over = to_implied(over_odds)
    p_under = to_implied(under_odds)
    total = p_over + p_under
    
    nv_over = p_over / total
    nv_under = p_under / total
    
    return {
        'over_prob': nv_over,
        'under_prob': nv_under,
        'fair_over': to_american(nv_over),
        'fair_under': to_american(nv_under),
        'vig': total - 1
    }
